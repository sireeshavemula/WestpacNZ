﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WestpacNZ.Pages;
using WestpacNZ.Util;

namespace WestpacNZ.Test
{
    [TestClass]
    public class KiwiSaverRetirementCalculatorTest
    {
        [TestMethod]
        public void VerifyKiwiSaverRetirementCalculatorFields()
        {
            Driver driver = new Driver();
            ChromeDriver chdriver = driver.InitialiseChrome();
            KiwiSaverRetirementCalculatorPage kiwiSaverPage = new KiwiSaverRetirementCalculatorPage();
            kiwiSaverPage.LoadKiwiSaverRetirementCalculator(chdriver);
            kiwiSaverPage.KiwiSaverCalculatorInformationCheck(chdriver);
            driver.QuitDriver(chdriver);
        }

        [TestMethod]
        public void VerifyKiwiSaverRetirementCalculatorInvestemntReturnEmployed()
        {
            Driver driver = new Driver();
            ChromeDriver chdriver = driver.InitialiseChrome();
            KiwiSaverRetirementCalculatorPage kiwiSaverPage = new KiwiSaverRetirementCalculatorPage();
            kiwiSaverPage.LoadKiwiSaverRetirementCalculator(chdriver);
            kiwiSaverPage.KiwiSaverCalculatorRetirementReturn(chdriver, "Employed");
            driver.QuitDriver(chdriver);
        }

        [TestMethod]
        public void VerifyKiwiSaverRetirementCalculatorInvestemntReturnSelfEmployed()
        {
            Driver driver = new Driver();
            ChromeDriver chdriver = driver.InitialiseChrome();
            KiwiSaverRetirementCalculatorPage kiwiSaverPage = new KiwiSaverRetirementCalculatorPage();
            kiwiSaverPage.LoadKiwiSaverRetirementCalculator(chdriver);
            kiwiSaverPage.KiwiSaverCalculatorRetirementReturn(chdriver, "SelfEmployed");
            driver.QuitDriver(chdriver);
        }

        [TestMethod]
        public void VerifyKiwiSaverRetirementCalculatorInvestemntReturnNotEmployed()
        {
            Driver driver = new Driver();
            ChromeDriver chdriver = driver.InitialiseChrome();
            KiwiSaverRetirementCalculatorPage kiwiSaverPage = new KiwiSaverRetirementCalculatorPage();
            kiwiSaverPage.LoadKiwiSaverRetirementCalculator(chdriver);
            kiwiSaverPage.KiwiSaverCalculatorRetirementReturn(chdriver, "NotEmployed");
            driver.QuitDriver(chdriver);
        }        
    }
}
