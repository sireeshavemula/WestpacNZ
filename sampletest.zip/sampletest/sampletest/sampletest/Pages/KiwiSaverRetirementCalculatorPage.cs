﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using WestpacNZ.Util;

namespace WestpacNZ.Pages
{
    public class KiwiSaverRetirementCalculatorPage
    {
        private IWebElement kiwiSaver;
        private IWebElement kiwiCalculator;
        private IWebElement clickHereBtn;
        private string currentAge;
        private int employmentStatus;
        private string salary;
        private string kiwiSaverMemberContribution;
        private int PIRRate;
        private string currentKiwiSaverBalance;
        private string voluntaryContributions;
        private int voluntaryContributionFrequency;
        private int riskProfile;
        private string savingsGoalatRetirement;
        private string testDataPath = @"D:\sampletest\sampletest\Util\TestDataExcel.xlsx";


        //This method helps us to navigate to KiwiSaver Retirement Calculator Page.
        public void LoadKiwiSaverRetirementCalculator(ChromeDriver chdriver)
        {
            kiwiSaver = chdriver.FindElement(By.XPath(".//*[@id='ubermenu-section-link-kiwisaver-ps']"));
            System.Threading.Thread.Sleep(1000);
            Actions act = new Actions(chdriver);
            act.MoveToElement(kiwiSaver).Build().Perform();
            //System.Threading.Thread.Sleep(1000);
            kiwiCalculator = chdriver.FindElement(By.XPath(".//*[@id='ubermenu-item-cta-kiwisaver-calculators-ps']"));
            string strCal = kiwiCalculator.Text;
            //act.MoveToElement(kiwiCalc).Perform();
            kiwiCalculator.Click();

            System.Threading.Thread.Sleep(2000);
            clickHereBtn = chdriver.FindElement(By.XPath(".//*[@id='content-ps']/div[2]/div/section/p[4]/a"));
            System.Threading.Thread.Sleep(2000);
            clickHereBtn.Click();
            System.Threading.Thread.Sleep(5000);
            chdriver.SwitchTo().Frame(chdriver.FindElement(By.XPath("//*[@id=\"calculator-embed\"]/iframe")));
        }

        //This method helps to check all the Information buttons are present with respect to the fields and also we are checking the description they display on click.
        public void KiwiSaverCalculatorInformationCheck(ChromeDriver chdriver)
        {
            ExcelHelper excel = new ExcelHelper();
            List <string> refMsgList = excel.GetKiwiSaverTestData(testDataPath, "InformationCheck");

            var mainBlock = ComputeIFrameElements(chdriver);
            var originalMsgList = new List<string>();

            //first click
            var selectBoxCtrl1 = mainBlock[1].FindElement(By.ClassName("select-control"));
            var selectBoxWell1 = selectBoxCtrl1.FindElement(By.ClassName("control-well"));
            selectBoxWell1.Click();
            var dropDownObj = selectBoxCtrl1.FindElement(By.ClassName("dropdown"))
                .FindElement(By.TagName("ul"))
                .FindElements(By.TagName("li"));
            dropDownObj[1].Click();
            mainBlock = ComputeIFrameElements(chdriver);

            //second click
            var selectBoxCtrl2 = mainBlock[4].FindElement(By.ClassName("adjacent-control-cell"));
            selectBoxCtrl2.FindElement(By.TagName("a")).Click();
            mainBlock = ComputeIFrameElements(chdriver);

            for (int i = 0; i < mainBlock.Count; i++)
            {
                if (i == 7) continue;
                else
                {
                    var tempRow = mainBlock[i].FindElement(By.ClassName("field-controls"));
                    var tempFieldInfo = mainBlock[i].FindElement(By.ClassName("field-info"));
                    //apply implicit wait.
                    tempFieldInfo.FindElement(By.ClassName("field-info-cell"))
                       .FindElement(By.TagName("button")).Click();
                    Thread.Sleep(1500);
                    //var textToComapare = tempRow.FindElement(By.ClassName("field-message"))
                    //    .FindElement(By.TagName("p")).Text;
                    originalMsgList.Add(tempRow.FindElement(By.ClassName("field-message"))
                        .FindElement(By.TagName("p")).Text);
                }
            }

            //Validate description for information button: Actual and Expected
            if (refMsgList.Except(originalMsgList).Count() == 0)
            {
                Console.WriteLine("error messgae");
            }
            else
            {
                for (int des = 0; des < refMsgList.Count; des++)
                {
                    Assert.AreEqual(originalMsgList[des].Trim(), refMsgList[des].Trim());

                }
            }

        }

        //This method helps to show the KiwiSaverRetirementReturn amount based on Employement Status
        public void KiwiSaverCalculatorRetirementReturn(ChromeDriver chdriver, string dataSheet)
        {
            var mainBlock = ComputeIFrameElements(chdriver);

            ExcelHelper excel = new ExcelHelper();
            List<string> refMsgList = excel.GetKiwiSaverTestData(testDataPath, dataSheet);

            if (dataSheet == "Employed")
            {
                currentAge = refMsgList[0].Trim();
                employmentStatus = 1;
                salary = refMsgList[2].Trim();
                kiwiSaverMemberContribution = refMsgList[3].Trim();
                PIRRate = Convert.ToInt32(refMsgList[4].Trim());
                riskProfile = Convert.ToInt32(refMsgList[5].Trim());
            }
            else if (dataSheet == "SelfEmployed")
            {
                currentAge = refMsgList[0].Trim();
                employmentStatus = 2;
                PIRRate = Convert.ToInt32(refMsgList[2].Trim());
                currentKiwiSaverBalance = refMsgList[3].Trim();
                voluntaryContributions = refMsgList[4].Trim();
                voluntaryContributionFrequency = Convert.ToInt32(refMsgList[5].Trim());
                riskProfile = Convert.ToInt32(refMsgList[6].Trim());
                savingsGoalatRetirement = refMsgList[7].Trim();
            }
            else
            {
                currentAge = refMsgList[0].Trim();
                employmentStatus = 3;
                PIRRate = Convert.ToInt32(refMsgList[2].Trim());
                currentKiwiSaverBalance = refMsgList[3].Trim();
                voluntaryContributions = refMsgList[4].Trim();
                voluntaryContributionFrequency = Convert.ToInt32(refMsgList[5].Trim());
                riskProfile = Convert.ToInt32(refMsgList[6].Trim());
                savingsGoalatRetirement = refMsgList[7].Trim();
            }

            var originalMsgList = new List<string>();
            //first click
            var selectBoxCtrl1 = mainBlock[1].FindElement(By.ClassName("select-control"));
            var selectBoxWell1 = selectBoxCtrl1.FindElement(By.ClassName("control-well"));
            selectBoxWell1.Click();
            var dropDownObj = selectBoxCtrl1.FindElement(By.ClassName("dropdown"))
                .FindElement(By.TagName("ul"))
                .FindElements(By.TagName("li"));
            dropDownObj[employmentStatus].Click();
            mainBlock = ComputeIFrameElements(chdriver);

            //currentage
            var textBoxCtrl = mainBlock[0].FindElement(By.ClassName("text-control"));
            textBoxCtrl.FindElement(By.ClassName("control-well"))
                .FindElement(By.TagName("input")).SendKeys(currentAge);
            Thread.Sleep(3000);

            if (employmentStatus == 1)
            {
                IWebElement salaryperanum = chdriver.FindElement(By.XPath(".//*[@id='widget']/div/div[1]/div/div[1]/div/div[3]/div/div/div/div[2]/div[1]/div[1]/div/div/div[1]/div/div/input"));
                Thread.Sleep(3000);
                salaryperanum.SendKeys(salary);

                IWebElement kiwiSavermemberContribution = chdriver.FindElement(By.XPath(".//*[@id='widget']/div/div[1]/div/div[1]/div/div[4]/div/div/div/div[2]/div[1]/div[1]/div/div/div/div/div[2]/div/label"));
                Thread.Sleep(3000);
                kiwiSavermemberContribution.Click();

                IWebElement PIRDropdown = chdriver.FindElement(By.XPath(".//*[@id='widget']/div/div[1]/div/div[1]/div/div[5]/div/div/div/div[2]/div[1]/div[1]/div/div[1]/div/div/div[1]"));
                Thread.Sleep(3000);
                PIRDropdown.Click();
                Thread.Sleep(3000);
                IWebElement PIROptions = chdriver.FindElement(By.XPath(".//*[@id='widget']/div/div[1]/div/div[1]/div/div[5]/div/div/div/div[2]/div[1]/div[1]/div/div[1]/div/div/div[2]/ul/div[" + PIRRate + "]/li/div"));
                PIROptions.Click();
            }
            else
            {
                IWebElement PIRDropdown = chdriver.FindElement(By.XPath(".//*[@id='widget']/div/div[1]/div/div[1]/div/div[3]/div/div/div/div[2]/div[1]/div[1]/div/div[1]/div/div/div[1]"));
                Thread.Sleep(3000);
                PIRDropdown.Click();
                Thread.Sleep(3000);
                IWebElement PIROptions = chdriver.FindElement(By.XPath(".//*[@id='widget']/div/div[1]/div/div[1]/div/div[3]/div/div/div/div[2]/div[1]/div[1]/div/div[1]/div/div/div[2]/ul/div[" + PIRRate + "]/li/div"));
                PIROptions.Click();
            }

            if (currentKiwiSaverBalance != null && employmentStatus == 1)
            {
                IWebElement currentbalance = chdriver.FindElement(By.XPath(".//*[@id='widget']/div/div[1]/div/div[1]/div/div[7]/div/div/div/div[2]/div[1]/div[1]/div/div/div[1]/div/div/input"));
                Thread.Sleep(3000);
                currentbalance.SendKeys(currentKiwiSaverBalance);
            }
            else if (currentKiwiSaverBalance != null)
            {
                IWebElement currentbalance = chdriver.FindElement(By.XPath(".//*[@id='widget']/div/div[1]/div/div[1]/div/div[5]/div/div/div/div[2]/div[1]/div[1]/div/div/div[1]/div/div/input"));
                Thread.Sleep(3000);
                currentbalance.SendKeys(currentKiwiSaverBalance);
            }

            if(voluntaryContributions != null && employmentStatus == 1)
            {
                IWebElement voluntarycontributions = chdriver.FindElement(By.XPath(".//*[@id='widget']/div/div[1]/div/div[1]/div/div[8]/div/div/div/div[2]/div[1]/div[1]/div/div/div[1]/div[1]/div/input"));
                Thread.Sleep(3000);
                voluntarycontributions.SendKeys(voluntaryContributions);
            }
            else if (voluntaryContributions != null)
            {
                IWebElement voluntarycontributions = chdriver.FindElement(By.XPath(".//*[@id='widget']/div/div[1]/div/div[1]/div/div[6]/div/div/div/div[2]/div[1]/div[1]/div/div/div[1]/div[1]/div/input"));
                Thread.Sleep(3000);
                voluntarycontributions.SendKeys(voluntaryContributions);
            }
            
            if(voluntaryContributionFrequency != 0 && employmentStatus == 1)
            {
                IWebElement voluntaryFrequency = chdriver.FindElement(By.XPath(".//*[@id='widget']/div/div[1]/div/div[1]/div/div[8]/div/div/div/div[2]/div[1]/div[1]/div/div/div[1]/div[2]/div/div[1]"));
                Thread.Sleep(3000);
                voluntaryFrequency.Click();
                Thread.Sleep(3000);
                IWebElement option = chdriver.FindElement(By.XPath(".//*[@id='widget']/div/div[1]/div/div[1]/div/div[8]/div/div/div/div[2]/div[1]/div[1]/div/div/div[1]/div[2]/div/div[2]/ul/li["+voluntaryContributionFrequency+"]/div"));
                Thread.Sleep(3000);
                option.Click();
            }
            else if (voluntaryContributionFrequency != 0)
            {
                IWebElement voluntaryFrequency = chdriver.FindElement(By.XPath(".//*[@id='widget']/div/div[1]/div/div[1]/div/div[6]/div/div/div/div[2]/div[1]/div[1]/div/div/div[1]/div[2]/div/div[1]"));
                Thread.Sleep(3000);
                voluntaryFrequency.Click();
                Thread.Sleep(3000);
                IWebElement option = chdriver.FindElement(By.XPath(".//*[@id='widget']/div/div[1]/div/div[1]/div/div[6]/div/div/div/div[2]/div[1]/div[1]/div/div/div[1]/div[2]/div/div[2]/ul/li["+voluntaryContributionFrequency+"]/div"));
                Thread.Sleep(3000);
                option.Click();
            }          

            //IWebElement mediumriskprofile =   chdriver.FindElement(By.XPath(".//*[@id='widget']/div/div[1]/div/div[1]/div/div[9]/div/div/div/div[2]/div[1]/div[1]/div/div/div/div/div[2]/div/label"));
            //   Thread.Sleep(3000);
            //   mediumriskprofile.Click();

            if(riskProfile != 0 && employmentStatus == 1)
            {
                IWebElement highriskprofile = chdriver.FindElement(By.XPath(".//*[@id='widget']/div/div[1]/div/div[1]/div/div[9]/div/div/div/div[2]/div[1]/div[1]/div/div[1]/div/div/div["+riskProfile+"]/div/label"));
                Thread.Sleep(3000);
                highriskprofile.Click();
            }
            else if (riskProfile != 0)
            {
                IWebElement highriskprofile = chdriver.FindElement(By.XPath(".//*[@id='widget']/div/div[1]/div/div[1]/div/div[7]/div/div/div/div[2]/div[1]/div[1]/div/div[1]/div/div/div[" + riskProfile + "]/div/label"));
                Thread.Sleep(3000);
                highriskprofile.Click();
            }

            if(savingsGoalatRetirement != null && employmentStatus == 1)
            {
                IWebElement savinggoal = chdriver.FindElement(By.XPath(".//*[@id='widget']/div/div[1]/div/div[1]/div/div[10]/div/div/div/div[2]/div[1]/div[1]/div/div/div[1]/div/div/input"));
                Thread.Sleep(3000);
                savinggoal.SendKeys(savingsGoalatRetirement);
            }
            else if (savingsGoalatRetirement != null)
            {
                IWebElement savinggoal = chdriver.FindElement(By.XPath(".//*[@id='widget']/div/div[1]/div/div[1]/div/div[8]/div/div/div/div[2]/div[1]/div[1]/div/div/div[1]/div/div/input"));
                Thread.Sleep(3000);
                savinggoal.SendKeys(savingsGoalatRetirement);
            }            

            IWebElement viewbutton = chdriver.FindElement(By.XPath(".//*[@id='widget']/div/div[1]/div/div[2]/button"));
            Thread.Sleep(3000);
            viewbutton.Click();

            Thread.Sleep(3000);
            IWebElement estimatedReturn = chdriver.FindElement(By.XPath(".//*[@id='widget']/div/div[1]/div/div[3]/div/div[1]/div[1]/div[1]/span[2]"));
            Assert.IsNotNull(estimatedReturn.Text);
            Console.WriteLine(estimatedReturn.Text);

            IWebElement estimatedpopup = chdriver.FindElement(By.XPath(".//*[@id='widget']/div/div[1]/div/div[3]/div/div[1]/div[1]/div[1]/div[1]/button"));
            Thread.Sleep(3000);
            estimatedpopup.Click();

            IWebElement entitlementsbutton = chdriver.FindElement(By.XPath(".//*[@id='widget']/div/div[1]/div/div[3]/div/div[1]/div[1]/div[2]/div[1]/div[2]/button"));
            Thread.Sleep(3000);
            entitlementsbutton.Click();

            IWebElement LifeExpentency = chdriver.FindElement(By.XPath(".//*[@id='widget']/div/div[1]/div/div[3]/div/div[3]/div[1]/div/div/div/div[2]/div[2]/div/div/div/button"));
            Thread.Sleep(3000);
            LifeExpentency.Click();

            IWebElement intendeddretirementage = chdriver.FindElement(By.XPath(".//*[@id='widget']/div/div[1]/div/div[3]/div/div[3]/div[2]/div/div/div/div[2]/div[2]/div/div/div/button"));
            Thread.Sleep(3000);
            intendeddretirementage.Click();

            IWebElement applyinflation = chdriver.FindElement(By.XPath(".//*[@id='widget']/div/div[1]/div/div[3]/div/div[3]/div[3]/div/div/div/div[2]/div[2]/div/div/div/button"));
            Thread.Sleep(3000);
            applyinflation.Click();


            if(employmentStatus == 1)
            {
                IWebElement incomeincrease = chdriver.FindElement(By.XPath(".//*[@id='widget']/div/div[1]/div/div[3]/div/div[3]/div[4]/div/div/div/div[2]/div[2]/div/div/div/button"));
                Thread.Sleep(3000);
                incomeincrease.Click();
            }
            
        }

      
        private IList<IWebElement> ComputeIFrameElements(ChromeDriver chdriver)
        {
            return chdriver.FindElement(By.ClassName("field-group-set-frame"))
                            .FindElements(By.ClassName("field-group"));
        }
        
    }
}
