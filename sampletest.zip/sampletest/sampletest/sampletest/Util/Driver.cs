﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WestpacNZ.Util
{
    public class Driver
    {
        public ChromeDriver InitialiseChrome()
        {
            ChromeDriver chdriver = new ChromeDriver();
            chdriver.Navigate().GoToUrl("http://www.westpac.co.nz/");
            chdriver.Manage().Window.Maximize();
            chdriver.Manage().Timeouts().ImplicitlyWait(TimeSpan.FromSeconds(10));
            return chdriver;
        }

        public void QuitDriver(ChromeDriver chdriver)
        {
            chdriver.Quit();
        }
    }
}
