﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;

namespace WestpacNZ.Util
{
    public class ExcelHelper
    {
        public List<string> GetKiwiSaverTestData(string excelPath, string dataSheet)
        {
            int row = 2, column = 1, sheet = 1;
            //Excel Connection
            Microsoft.Office.Interop.Excel.Application xlApp = new Excel.Application();
            Microsoft.Office.Interop.Excel.Workbook xlBook = xlApp.Workbooks.Open(excelPath);

            var refMsgList = new List<string>();
            if(dataSheet == "InformationCheck")
            {
                sheet = 1;
            }
            else if (dataSheet == "Employed")
            {
                sheet = 2;
            }
            else if (dataSheet == "SelfEmployed")
            {
                sheet = 3;
            }
            else if (dataSheet == "NotEmployed")
            {
                sheet = 4;
            }
            try
            {
                Excel.Worksheet xlsheet = xlBook.Sheets[sheet];
                Excel.Range xlRange = xlsheet.UsedRange;
                while ((xlRange.Cells[row, column] as Excel.Range).Value2 != null)
                {
                    refMsgList.Add(Convert.ToString((xlRange.Cells[row, column] as Excel.Range).Value2));
                    row++;
                }
            }
            catch(Exception e)
            {
                throw e;
            }
            finally
            {
                xlApp.Quit();
            }
            
            return refMsgList;
        }
    }
}
